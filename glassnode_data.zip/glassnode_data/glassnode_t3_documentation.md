# Glassnode T3 Metrics Documentation

Total Metrics: 45
Total Groups: 6
Total Categories: 9

## Metrics by Group

### Activity (9 metrics)

| Metric Name | API Endpoint | Full URL | Category |
|-------------|--------------|----------|----------|
| active_addresses | `addresses/active_count` | https://api.glassnode.com/v1/metrics/addresses/active_count | addresses |
| mean_tx_value | `transactions/transfers_volume_to_exchanges_mean` | https://api.glassnode.com/v1/metrics/transactions/transfers_volume_to_exchanges_mean | transactions |
| new_addresses | `addresses/new_non_zero_count` | https://api.glassnode.com/v1/metrics/addresses/new_non_zero_count | addresses |
| nvt_ratio | `indicators/nvt` | https://api.glassnode.com/v1/metrics/indicators/nvt | indicators |
| nvts | `indicators/nvts` | https://api.glassnode.com/v1/metrics/indicators/nvts | indicators |
| transaction_count | `transactions/count` | https://api.glassnode.com/v1/metrics/transactions/count | transactions |
| transaction_fees | `fees/volume_sum` | https://api.glassnode.com/v1/metrics/fees/volume_sum | fees |
| transaction_volume | `transactions/transfers_volume_sum` | https://api.glassnode.com/v1/metrics/transactions/transfers_volume_sum | transactions |
| velocity | `indicators/velocity` | https://api.glassnode.com/v1/metrics/indicators/velocity | indicators |

### Exchange (9 metrics)

| Metric Name | API Endpoint | Full URL | Category |
|-------------|--------------|----------|----------|
| exchange_inflow | `transactions/transfers_volume_to_exchanges_sum` | https://api.glassnode.com/v1/metrics/transactions/transfers_volume_to_exchanges_sum | transactions |
| exchange_inflow_mean | `transactions/transfers_volume_to_exchanges_mean` | https://api.glassnode.com/v1/metrics/transactions/transfers_volume_to_exchanges_mean | transactions |
| exchange_net_flow | `transactions/transfers_volume_exchanges_net` | https://api.glassnode.com/v1/metrics/transactions/transfers_volume_exchanges_net | transactions |
| exchange_net_position_change | `distribution/exchange_net_position_change` | https://api.glassnode.com/v1/metrics/distribution/exchange_net_position_change | distribution |
| exchange_outflow | `transactions/transfers_volume_from_exchanges_sum` | https://api.glassnode.com/v1/metrics/transactions/transfers_volume_from_exchanges_sum | transactions |
| exchange_outflow_mean | `transactions/transfers_volume_from_exchanges_mean` | https://api.glassnode.com/v1/metrics/transactions/transfers_volume_from_exchanges_mean | transactions |
| exchange_reserve | `distribution/balance_exchanges` | https://api.glassnode.com/v1/metrics/distribution/balance_exchanges | distribution |
| illiquid_supply | `supply/illiquid_sum` | https://api.glassnode.com/v1/metrics/supply/illiquid_sum | supply |
| liquid_supply | `supply/liquid_sum` | https://api.glassnode.com/v1/metrics/supply/liquid_sum | supply |

### Long Term Holders (7 metrics)

| Metric Name | API Endpoint | Full URL | Category |
|-------------|--------------|----------|----------|
| coin_days_destroyed | `indicators/cdd` | https://api.glassnode.com/v1/metrics/indicators/cdd | indicators |
| hodl_waves | `supply/hodl_waves` | https://api.glassnode.com/v1/metrics/supply/hodl_waves | supply |
| liveliness | `indicators/liveliness` | https://api.glassnode.com/v1/metrics/indicators/liveliness | indicators |
| lth_sopr | `indicators/sopr_more_155` | https://api.glassnode.com/v1/metrics/indicators/sopr_more_155 | indicators |
| lth_supply | `supply/lth_sum` | https://api.glassnode.com/v1/metrics/supply/lth_sum | supply |
| realized_cap_hodl_waves | `supply/rcap_hodl_waves` | https://api.glassnode.com/v1/metrics/supply/rcap_hodl_waves | supply |
| sth_supply | `supply/sth_sum` | https://api.glassnode.com/v1/metrics/supply/sth_sum | supply |

### Mining (4 metrics)

| Metric Name | API Endpoint | Full URL | Category |
|-------------|--------------|----------|----------|
| difficulty | `mining/difficulty_latest` | https://api.glassnode.com/v1/metrics/mining/difficulty_latest | mining |
| hash_rate | `mining/hash_rate_mean` | https://api.glassnode.com/v1/metrics/mining/hash_rate_mean | mining |
| miner_revenue | `mining/revenue_sum` | https://api.glassnode.com/v1/metrics/mining/revenue_sum | mining |
| miner_revenue_usd | `mining/revenue_sum` | https://api.glassnode.com/v1/metrics/mining/revenue_sum | mining |

### Profitability (9 metrics)

| Metric Name | API Endpoint | Full URL | Category |
|-------------|--------------|----------|----------|
| asopr | `indicators/sopr_adjusted` | https://api.glassnode.com/v1/metrics/indicators/sopr_adjusted | indicators |
| mvrv | `market/mvrv` | https://api.glassnode.com/v1/metrics/market/mvrv | market |
| mvrv_zscore | `market/mvrv_z_score` | https://api.glassnode.com/v1/metrics/market/mvrv_z_score | market |
| nupl | `indicators/net_unrealized_profit_loss` | https://api.glassnode.com/v1/metrics/indicators/net_unrealized_profit_loss | indicators |
| percent_supply_in_profit | `supply/sth_profit_loss_ratio` | https://api.glassnode.com/v1/metrics/supply/sth_profit_loss_ratio | supply |
| realized_cap | `market/marketcap_realized_usd` | https://api.glassnode.com/v1/metrics/market/marketcap_realized_usd | market |
| realized_price | `market/price_realized_usd` | https://api.glassnode.com/v1/metrics/market/price_realized_usd | market |
| realized_profit_loss_ratio | `indicators/realized_profit_loss_ratio` | https://api.glassnode.com/v1/metrics/indicators/realized_profit_loss_ratio | indicators |
| sopr | `indicators/sopr` | https://api.glassnode.com/v1/metrics/indicators/sopr | indicators |

### Smart Money (7 metrics)

| Metric Name | API Endpoint | Full URL | Category |
|-------------|--------------|----------|----------|
| accumulation_trend_score | `indicators/accumulation_trend_score` | https://api.glassnode.com/v1/metrics/indicators/accumulation_trend_score | indicators |
| balance_1k_to_10k | `addresses/min_1k_count` | https://api.glassnode.com/v1/metrics/addresses/min_1k_count | addresses |
| binary_coin_days_destroyed | `indicators/cdd_supply_adjusted_binary` | https://api.glassnode.com/v1/metrics/indicators/cdd_supply_adjusted_binary | indicators |
| supply_retention_cohorts | `supply/holder_retention` | https://api.glassnode.com/v1/metrics/supply/holder_retention | supply |
| whale_balance | `entities/supply_balance_1k_10k` | https://api.glassnode.com/v1/metrics/entities/supply_balance_1k_10k | entities |
| whale_outflow | `distribution/exchange_whales_outflow` | https://api.glassnode.com/v1/metrics/distribution/exchange_whales_outflow | distribution |
| whale_transaction_count | `entities/min_1k_count` | https://api.glassnode.com/v1/metrics/entities/min_1k_count | entities |

